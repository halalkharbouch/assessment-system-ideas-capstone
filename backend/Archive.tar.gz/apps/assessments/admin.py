from django.contrib import admin
from .models import Assessment

admin.site.register(Assessment)

# Register your models here.
